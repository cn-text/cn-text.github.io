//====================DIVISION====================
//==========DIVISION==========
ASP_CLS.VAL.Audio_List_ARR=[];
ASP_CLS.VAL.Audio_List_Mode_ARR=
[
	//==========DIVISION==========
	[
		"DFJF_MP3\\Dalian40k_1.mp3",
		"DFJF_MP3\\Dalian40k_2.mp3",
		"DFJF_MP3\\Dalian40k_3.mp3",
		"DFJF_MP3\\Dalian40k_4.mp3",
		"DFJF_MP3\\Dalian40k_5.mp3",
		"DFJF_MP3\\Dalian40k_6.mp3",
		"DFJF_MP3\\Dalian40k_7.mp3",
		"DFJF_MP3\\Dalian40k_8.mp3",
		"DFJF_MP3\\Dalian40k_9.mp3",
	],
	[
		"DFJF_MP3\\Guangzhou40k_1.mp3",
		"DFJF_MP3\\Guangzhou40k_2.mp3",
		"DFJF_MP3\\Guangzhou40k_3.mp3",
		"DFJF_MP3\\Guangzhou40k_4.mp3",
		"DFJF_MP3\\Guangzhou40k_5.mp3",
		"DFJF_MP3\\Guangzhou40k_6.mp3",
		"DFJF_MP3\\Guangzhou40k_7.mp3",
		"DFJF_MP3\\Guangzhou40k_8.mp3",
		"DFJF_MP3\\Guangzhou40k_9.mp3",
	],
	[
		"DFJF_MP3\\Jinan40k_1.mp3",
		"DFJF_MP3\\Jinan40k_2.mp3",
		"DFJF_MP3\\Jinan40k_3.mp3",
		"DFJF_MP3\\Jinan40k_4.mp3",
		"DFJF_MP3\\Jinan40k_5.mp3",
		"DFJF_MP3\\Jinan40k_6.mp3",
		"DFJF_MP3\\Jinan40k_7.mp3",
		"DFJF_MP3\\Jinan40k_8.mp3",
		"DFJF_MP3\\Jinan40k_9.mp3",
	],
	[
		"DF_Exercise_MP3\\exercise_1.mp3",
		"DF_Exercise_MP3\\exercise_2.mp3",
		"DF_Exercise_MP3\\exercise_3.mp3",
		"DF_Exercise_MP3\\exercise_4.mp3",
		"DF_Exercise_MP3\\exercise_5.mp3",
	],
	["ALL_4(0-3)"],
	//==========DIVISION==========
	[
		//==========DIVISION==========
		"ET_BGM\\ET_BGM_01\\CB_01_04_ORI\\CB_01_00_00_000_00_E_LHZ.mp3",
		"ET_BGM\\ET_BGM_01\\CB_01_04_ORI\\CB_01_00_00_001_00_E_ZSR.mp3",
		"ET_BGM\\ET_BGM_01\\CB_01_04_ORI\\CB_01_00_00_001_01_E_ZSR.mp3",
		"ET_BGM\\ET_BGM_01\\CB_01_04_ORI\\CB_01_00_00_001_02_E_ZSR.mp3",
		"ET_BGM\\ET_BGM_01\\CB_01_04_ORI\\CB_01_00_00_002_00_E_FLG.mp3",
		"ET_BGM\\ET_BGM_01\\CB_01_04_ORI\\CB_01_00_00_002_01_E_FLG.mp3",
		"ET_BGM\\ET_BGM_01\\CB_01_04_ORI\\CB_01_00_00_002_02_E_FLG.mp3",
		"ET_BGM\\ET_BGM_01\\CB_01_04_ORI\\CB_01_00_00_003_00_E_FLDF.mp3",
		//==========DIVISION==========
		"ET_BGM\\ET_BGM_02\\ZSR_00_CB_01_02_ORI\\CB_01_02_00_001_10_00_Z.mp3",
		"ET_BGM\\ET_BGM_02\\ZSR_00_CB_01_02_ORI\\CB_01_02_00_001_10_01_Z.mp3",
		"ET_BGM\\ET_BGM_02\\ZSR_00_CB_01_02_ORI\\CB_01_02_00_001_10_02_Z.mp3",
		"ET_BGM\\ET_BGM_02\\ZSR_00_CB_01_02_ORI\\CB_01_02_00_001_11_00_S.mp3",
		"ET_BGM\\ET_BGM_02\\ZSR_00_CB_01_02_ORI\\CB_01_02_00_001_11_01_S.mp3",
		"ET_BGM\\ET_BGM_02\\ZSR_00_CB_01_02_ORI\\CB_01_02_00_001_11_02_S.mp3",
		"ET_BGM\\ET_BGM_02\\ZSR_00_CB_01_02_ORI\\CB_01_02_00_001_12_00_R.mp3",
		"ET_BGM\\ET_BGM_02\\ZSR_00_CB_01_02_ORI\\CB_01_02_00_001_12_01_R.mp3",
		"ET_BGM\\ET_BGM_02\\ZSR_00_CB_01_02_ORI\\CB_01_02_00_001_12_02_R.mp3",
		"ET_BGM\\ET_BGM_02\\ZSR_00_CB_01_02_ORI\\CB_01_02_00_001_12_03_R.mp3",
		"ET_BGM\\ET_BGM_02\\ZSR_00_CB_01_02_ORI\\CB_01_02_00_001_12_10_R.mp3",
		"ET_BGM\\ET_BGM_02\\ZSR_00_CB_01_02_ORI\\CB_01_02_00_001_12_11_R.mp3",
		"ET_BGM\\ET_BGM_02\\ZSR_00_CB_01_02_ORI\\CB_01_02_00_001_12_12_R.mp3",
		"ET_BGM\\ET_BGM_02\\ZSR_00_CB_01_02_ORI\\CB_01_02_00_001_12_13_R.mp3",
		"ET_BGM\\ET_BGM_02\\ZSR_00_CB_01_02_ORI\\CB_01_02_00_001_12_14_R.mp3",
		//==========DIVISION==========
		"ET_BGM\\ET_BGM_03\\CB_01_02_ORI\\CB_01_02_00_001_20_00_Z.mp3",
		"ET_BGM\\ET_BGM_03\\CB_01_02_ORI\\CB_01_02_00_001_20_01_Z.mp3",
		"ET_BGM\\ET_BGM_03\\CB_01_02_ORI\\CB_01_02_00_001_20_02_Z.mp3",
		"ET_BGM\\ET_BGM_03\\CB_01_02_ORI\\CB_01_02_00_001_21_00_S.mp3",
		"ET_BGM\\ET_BGM_03\\CB_01_02_ORI\\CB_01_02_00_001_21_01_S.mp3",
		"ET_BGM\\ET_BGM_03\\CB_01_02_ORI\\CB_01_02_00_001_21_02_S.mp3",
		"ET_BGM\\ET_BGM_03\\CB_01_02_ORI\\CB_01_02_00_001_22_00_R.mp3",
		"ET_BGM\\ET_BGM_03\\CB_01_02_ORI\\CB_01_02_00_001_22_01_R.mp3",
		"ET_BGM\\ET_BGM_03\\CB_01_02_ORI\\CB_01_02_00_001_22_02_R.mp3",
		"ET_BGM\\ET_BGM_03\\CB_01_02_ORI\\CB_01_02_00_001_22_03_R.mp3",
		"ET_BGM\\ET_BGM_03\\CB_01_02_ORI\\CB_01_02_00_001_22_04_R.mp3",
		"ET_BGM\\ET_BGM_03\\CB_01_02_ORI\\CB_01_02_00_001_22_05_R.mp3",
		"ET_BGM\\ET_BGM_03\\CB_01_02_ORI\\CB_01_02_00_002_00_00_ZSR.mp3",
		//==========DIVISION==========
	],
	[
		//==========DIVISION==========
		"ET_BGM\\ET_BGM_01\\CB_01_14_ORI_X\\CB_01_00_00_000_00_E_LHZ_X2048.mp3",
		"ET_BGM\\ET_BGM_01\\CB_01_14_ORI_X\\CB_01_00_00_001_00_E_ZSR_X1024.mp3",
		"ET_BGM\\ET_BGM_01\\CB_01_14_ORI_X\\CB_01_00_00_001_01_E_ZSR_X1024.mp3",
		"ET_BGM\\ET_BGM_01\\CB_01_14_ORI_X\\CB_01_00_00_001_02_E_ZSR_X1024.mp3",
		"ET_BGM\\ET_BGM_01\\CB_01_14_ORI_X\\CB_01_00_00_002_00_E_FLG_X1024.mp3",
		"ET_BGM\\ET_BGM_01\\CB_01_14_ORI_X\\CB_01_00_00_002_01_E_FLG_X1024.mp3",
		"ET_BGM\\ET_BGM_01\\CB_01_14_ORI_X\\CB_01_00_00_002_02_E_FLG_X1024.mp3",
		"ET_BGM\\ET_BGM_01\\CB_01_14_ORI_X\\CB_01_00_00_003_00_E_FLDF_X2048.mp3",
		//==========DIVISION==========
		"ET_BGM\\ET_BGM_02\\ZSR_00_CB_01_12_ORI_X\\CB_01_12_00_001_10_00_Z_X1024.mp3",
		"ET_BGM\\ET_BGM_02\\ZSR_00_CB_01_12_ORI_X\\CB_01_12_00_001_10_01_Z_X2048.mp3",
		"ET_BGM\\ET_BGM_02\\ZSR_00_CB_01_12_ORI_X\\CB_01_12_00_001_10_02_Z_X4096.mp3",
		"ET_BGM\\ET_BGM_02\\ZSR_00_CB_01_12_ORI_X\\CB_01_12_00_001_11_00_S_X1024.mp3",
		"ET_BGM\\ET_BGM_02\\ZSR_00_CB_01_12_ORI_X\\CB_01_12_00_001_11_01_S_X2048.mp3",
		"ET_BGM\\ET_BGM_02\\ZSR_00_CB_01_12_ORI_X\\CB_01_12_00_001_11_02_S_X4096.mp3",
		"ET_BGM\\ET_BGM_02\\ZSR_00_CB_01_12_ORI_X\\CB_01_12_00_001_12_00_R_X1024.mp3",
		"ET_BGM\\ET_BGM_02\\ZSR_00_CB_01_12_ORI_X\\CB_01_12_00_001_12_01_R_X1024.mp3",
		"ET_BGM\\ET_BGM_02\\ZSR_00_CB_01_12_ORI_X\\CB_01_12_00_001_12_02_R_X2048.mp3",
		"ET_BGM\\ET_BGM_02\\ZSR_00_CB_01_12_ORI_X\\CB_01_12_00_001_12_03_R_X4096.mp3",
		"ET_BGM\\ET_BGM_02\\ZSR_00_CB_01_12_ORI_X\\CB_01_12_00_001_12_10_R_X1024.mp3",
		"ET_BGM\\ET_BGM_02\\ZSR_00_CB_01_12_ORI_X\\CB_01_12_00_001_12_11_R_X1024.mp3",
		"ET_BGM\\ET_BGM_02\\ZSR_00_CB_01_12_ORI_X\\CB_01_12_00_001_12_12_R_X1024.mp3",
		"ET_BGM\\ET_BGM_02\\ZSR_00_CB_01_12_ORI_X\\CB_01_12_00_001_12_13_R_X2048.mp3",
		"ET_BGM\\ET_BGM_02\\ZSR_00_CB_01_12_ORI_X\\CB_01_12_00_001_12_14_R_X4096.mp3",
		//==========DIVISION==========
		"ET_BGM\\ET_BGM_03\\CB_01_12_ORI_X\\CB_01_12_00_001_20_00_Z_X4096.mp3",
		"ET_BGM\\ET_BGM_03\\CB_01_12_ORI_X\\CB_01_12_00_001_20_01_Z_X4096.mp3",
		"ET_BGM\\ET_BGM_03\\CB_01_12_ORI_X\\CB_01_12_00_001_20_02_Z_X4096.mp3",
		"ET_BGM\\ET_BGM_03\\CB_01_12_ORI_X\\CB_01_12_00_001_21_00_S_X4096.mp3",
		"ET_BGM\\ET_BGM_03\\CB_01_12_ORI_X\\CB_01_12_00_001_21_01_S_X4096.mp3",
		"ET_BGM\\ET_BGM_03\\CB_01_12_ORI_X\\CB_01_12_00_001_21_02_S_X4096.mp3",
		"ET_BGM\\ET_BGM_03\\CB_01_12_ORI_X\\CB_01_12_00_001_22_00_R_X4096.mp3",
		"ET_BGM\\ET_BGM_03\\CB_01_12_ORI_X\\CB_01_12_00_001_22_01_R_X4096.mp3",
		"ET_BGM\\ET_BGM_03\\CB_01_12_ORI_X\\CB_01_12_00_001_22_02_R_X4096.mp3",
		"ET_BGM\\ET_BGM_03\\CB_01_12_ORI_X\\CB_01_12_00_001_22_03_R_X4096.mp3",
		"ET_BGM\\ET_BGM_03\\CB_01_12_ORI_X\\CB_01_12_00_001_22_04_R_X4096.mp3",
		"ET_BGM\\ET_BGM_03\\CB_01_12_ORI_X\\CB_01_12_00_001_22_05_R_X4096.mp3",
		"ET_BGM\\ET_BGM_03\\CB_01_12_ORI_X\\CB_01_12_00_002_00_00_ZSR_X1024.mp3",
		//==========DIVISION==========
	],
	//==========DIVISION==========
];
//==========DIVISION==========
ASP_CLS.VAL.Audio_List_Name_ARR=
[
	"大連講法",
	"廣州講法",
	"濟南講法",
	"練功音樂",
	"全部講法+練功",
	"ET_BGM_Short",
	"ET_BGM_Long",
];
//==========DIVISION==========
Audio_List_ARR_INI();
//==========DIVISION==========
//====================DIVISION====================
//==========DIVISION==========
//			[
//				[
//					[{Name:"ASD_00",Type:0,Audio_List_ID:1}],
//					[
//						[AR_ID,BcurrentTime,EcurrentTime,BECT_Convert_Type,Volume,Speed],
//						[AR_ID,BcurrentTime,EcurrentTime,BECT_Convert_Type,Volume,Speed],
//						[AR_ID,BcurrentTime,EcurrentTime,BECT_Convert_Type,Volume,Speed],
//						[AR_ID,BcurrentTime,EcurrentTime,BECT_Convert_Type,Volume,Speed],
//						[AR_ID,BcurrentTime,EcurrentTime,BECT_Convert_Type,Volume,Speed],
//					],
//				],
//				[
//					[{Name:"ASD_01",Type:1}],
//					[
//						[Audio_List_ID,AR_ID,BcurrentTime,EcurrentTime,BECT_Convert_Type,Volume,Speed],
//						[Audio_List_ID,AR_ID,BcurrentTime,EcurrentTime,BECT_Convert_Type,Volume,Speed],
//						[Audio_List_ID,AR_ID,BcurrentTime,EcurrentTime,BECT_Convert_Type,Volume,Speed],
//						[Audio_List_ID,AR_ID,BcurrentTime,EcurrentTime,BECT_Convert_Type,Volume,Speed],
//						[Audio_List_ID,AR_ID,BcurrentTime,EcurrentTime,BECT_Convert_Type,Volume,Speed],
//					],
//				],
//				[
//					[{Name:"ASD_02",Type:2,Audio_List_ID:6,Cycle_Outer:[10,1],New_MP3_ARR:["AAA.mp3","BBB.mp3","CCC.mp3"]}],//Multi_MP3_Tunnel;
//					[
//						[AR_ID,BcurrentTime,EcurrentTime,BECT_Convert_Type,Volume,Speed,Repeat_Time],
//						[AR_ID,BcurrentTime,EcurrentTime,BECT_Convert_Type,Volume,Speed,Repeat_Time],
//						[AR_ID,BcurrentTime,EcurrentTime,BECT_Convert_Type,Volume,Speed,Repeat_Time],
//						[AR_ID,BcurrentTime,EcurrentTime,BECT_Convert_Type,Volume,Speed,Repeat_Time],
//					],
//					[
//						[AR_ID,BcurrentTime,EcurrentTime,BECT_Convert_Type,Volume,Speed,Repeat_Time],
//					],
//					[
//						[AR_ID,BcurrentTime,EcurrentTime,BECT_Convert_Type,Volume,Speed,Repeat_Time],
//						[AR_ID,BcurrentTime,EcurrentTime,BECT_Convert_Type,Volume,Speed,Repeat_Time],
//					],
//				],
//				[
//					[{Name:"真、善、忍◯",Type:3,Audio_List_ID:1,
//						//	Cycle_Outer:[1],	Cycle_Inner:[[1,3]],
//						//	Cycle_Outer:[1],	Cycle_Inner:[[1,"'1-3'"]],
//						Cycle_Outer:[1],	Cycle_Inner:[["'1-3'","'1-3'"]],
//						Random_Order_Inner:[1],	Random_Order_Inner_Inner:[[0,1]],
//						New_MP3_ARR:[]}],//Multi_MP3_Tunnel;
//					[
//						//==========DIVISION==========
//						//FIA:Function_INT_ALL;
//						//FIB:Function_INT_Begin;
//						//FIE:Function_INT_End;
//						//FFA:Function_FLOAT_ALL;
//						//FFB:Function_FLOAT_Begin;
//						//FFE:Function_FLOAT_End;
//						//==========DIVISION==========
//						[
//							//==========DIVISION==========
//							//	[0*9+0,"00.40.55.900","00.40.56.200",0,1,1,1],				
//							//	[0*9+0,"00.40.56.540","00.40.56.840",0,1,30/30,1],			
//							//	[0*9+0,"00.40.57.360","00.40.57.760",0,1,40/30,"'1-3'"],	
//							[0*9+0,"00.40.55.900","00.40.56.200",0,1,"'FFB(30/30)-0.2FFE(30/30)+0.2'","'1-3'"],
//							[0*9+0,"00.40.56.540","00.40.56.840",0,1,"'FFB(30/30)-0.2FFE(30/30)+0.2'","'1-3'"],
//							[0*9+0,"00.40.57.360","00.40.57.760",0,1,"'FFB(40/30)-0.2FFE(40/30)+0.2'","'1-3'"],
//							//==========DIVISION==========
//						],
//						//==========DIVISION==========
//						[
//							[0*9+0,"00.40.55.900","00.40.56.200",0,1,"'FFB(30/30)-0.2FFE(30/30)+0.2'","'1-3'"],
//							[0*9+0,"00.40.56.540","00.40.56.840",0,1,"'FFB(30/30)-0.2FFE(30/30)+0.2'","'1-3'"],
//							[0*9+0,"00.40.57.360","00.40.57.760",0,1,"'FFB(40/30)-0.2FFE(40/30)+0.2'","'1-3'"],
//						],
//						//==========DIVISION==========
//					],
//				],
//				[
//					[{Name:"真、善、忍",Type:3,Audio_List_ID:4,
//						//	Cycle_Outer:[1],	Cycle_Inner:[[1,3]],
//						//	Cycle_Outer:[1],	Cycle_Inner:[[1,"'1-3'"]],
//						Cycle_Outer:[1],	Cycle_Inner:[["'1-3'","'1-3'"]],
//						Random_Order_Inner:[0],	Random_Order_Inner_Inner:[[0,0]],
//						New_MP3_ARR:[]}],//Multi_MP3_Tunnel;
//					[
//						//==========DIVISION==========
//						[0*9+0,
//						"F_0000_#FVB#0,1,2#FVE#00.40.55.900,00.40.56.540,00.40.57.360",
//						"F_0000_#FVB#0,1,2#FVE#00.40.56.200,00.40.56.840,00.40.57.760",
//						0,
//						"0.84,0.84,0.84",
//						"F_0000_#FVB#0,1,2#FVE#'0.3-1.2','0.3-1.2','0.4-1.6'",
//						1],
//
//						[0*9+0,
//						"F_TA_#FVB#0,1,2#FVE#00.40.55.900,00.40.56.540,00.40.57.360",
//						"F_TA_#FVB#0,1,2#FVE#00.40.56.200,00.40.56.840,00.40.57.760",
//						0,
//						"0.84,0.84,0.84",
//						"F_TA_#FVB#0,1,2#FVE#'0.3-1.2','0.3-1.2','0.4-1.6'",
//						1],
//						//==========DIVISION==========
//					],
//				],
//			];
//==========DIVISION==========
//	if ( BECT_CVT_Type==0 )//【ETime<=ele00.duration】
//	else if ( BECT_CVT_Type==1 )//【ETime>ele00.duration】：增加一个数组，播放时间从0开始。
//	else if ( BECT_CVT_Type==2 )//loop，循环播放。
//==========DIVISION==========
ASP_CLS.VAL.Audio_Section_Data_ARR=
[
	//==============================DIVISION==============================
	[
		[
			[{Name:"随机声音截段:[李洪志声音震荡机(随机)_00_ALID_3]",Type:2,Audio_List_ID:3,Cycle_Outer:[1,1],New_MP3_ARR:[]}],//Multi_MP3_Tunnel;
			[
				[0,"00.01.13.200","00.01.15.500",0,1,1,10],
			],
		],
	],
	[
		[
			[{Name:"随机声音截段:[李洪志声音震荡机(随机)_01_ALID_0]",Type:2,Audio_List_ID:0,Cycle_Outer:[1,1],New_MP3_ARR:[]}],//Multi_MP3_Tunnel;
			[
				[6,"01.06.33.050","01.06.33.390",0,1,1,10],
			],
		],
	],
	[
		[
			[{Name:"随机声音截段:[李洪志声音震荡机(随机)_02_ALID_1]",Type:2,Audio_List_ID:1,Cycle_Outer:[1,1],New_MP3_ARR:[]}],//Multi_MP3_Tunnel;
			[
				[6,"01.06.33.050","01.06.33.390",0,1,1,10],
			],
		],
	],
	[
		[
			[{Name:"随机声音截段:[李洪志声音震荡机(随机)_03_ALID_2]",Type:2,Audio_List_ID:2,Cycle_Outer:[1,1],New_MP3_ARR:[]}],//Multi_MP3_Tunnel;
			[
				[6,"01.06.33.050","01.06.33.390",0,1,1,10],
			],
		],
	],
	[
		[
			//[{Name:"随机声音截段:[李洪志声音震荡机(随机)_00_ALID_4]",Type:2,Audio_List_ID:4,Cycle_Outer:[1,1],New_MP3_ARR:["Audio\\Slient_10MIN.mp3"]}],//Multi_MP3_Tunnel;
			[{Name:"随机声音截段:[李洪志声音震荡机(随机)_04_ALID_4]",Type:2,Audio_List_ID:4,Cycle_Outer:[1,1],New_MP3_ARR:[]}],//Multi_MP3_Tunnel;
			[
				[6,"01.06.33.050","01.06.33.390",0,1,1,10],
			],
		],
	],
	//==============================DIVISION==============================
	[
		[
			[{Name:"李洪志好，真善忍好，法輪功好，法輪大法好。",Type:1}],
			[
				[4,1*9+2,"01.33.02.820","01.33.03.420",0,1,0.75],	[4,1*9+8,"01.31.52.150","01.31.52.500",0,1,1],
				[4,1*9+0,"00.40.55.870","00.40.58.500",0,1,1],		[4,1*9+8,"01.31.52.150","01.31.52.500",0,1,1],
				[4,1*9+0,"00.01.09.470","00.01.10.270",0,1,1],		[4,1*9+8,"01.31.52.150","01.31.52.500",0,1,1],
				[4,1*9+0,"01.27.09.800","01.27.10.800",0,1,1],		[4,1*9+8,"01.31.52.150","01.31.52.500",0,1,1],
			],
		],
	],
	[
		[
			[{Name:"李洪志轉法輪。",Type:1}],
			[
				[1,2,"01.33.02.820","01.33.03.420",0,1,0.75],
				[1,0,"01.33.33.400","01.33.33.640",0,1,0.6],
				[1,0,"01.33.28.010","01.33.28.720",0,1,1],
			],
		],
	],
	//==============================DIVISION==============================
	[
		[
			//"Guangzhou40k_1.mp3"	00.40.55.870-00.40.58.500	//真、善、忍
			[{Name:"真、善、忍",Type:2,Audio_List_ID:1,Cycle_Outer:[1],New_MP3_ARR:[""]}],//Multi_MP3_Tunnel;
			[
				//==========DIVISION==========
				//	[0*9+0,"00.40.55.900","00.40.56.200",0,1,1,1],		//0.300
				//	[0*9+0,"00.40.56.540","00.40.56.840",0,1,1.5,1],	//0.300
				//	[0*9+0,"00.40.57.360","00.40.57.760",0,1,2,1],		//0.400
				//==========DIVISION==========
				//	[0*9+0,"00.40.55.900","00.40.56.200",0,1,0.75,1],	["0*9+0,0*9+0,0*9+0","00.40.55.900,00.40.56.540,00.40.57.360","00.40.56.200,00.40.56.840,00.40.57.760",0,1,1,1],
				//==========DIVISION==========
				//	["0*9+0,0*9+0,0*9+0","00.40.55.900,00.40.56.540,00.40.57.360","00.40.56.200,00.40.56.840,00.40.57.760",0,1,"0.3,0.3,0.4",1],
				//	[1*9+7,"00.40.55.900","00.40.56.200",0,1,"0.3,0.6,0.9",1],
				//	[1*9+7,"00.40.55.900","00.40.56.200",0,1,"0.1,1,5",1],
				//==========DIVISION==========
				//	[0*9+0,"00.40.55.900,00.40.56.540,00.40.57.360","00.40.56.200,00.40.56.840,00.40.57.760",0,1,"'0.3-1.2','0.3-1.2','0.4-1.6'",1],
				//	["0*9+0,0*9+0,0*9+0","00.40.55.900,00.40.56.540,00.40.57.360","00.40.56.200,00.40.56.840,00.40.57.760",0,1,"'0.3-1.2','0.3-1.2','0.4-1.6'",1],
				//==========DIVISION==========
				//==========
				//["AR_ID","BcurrentTime","EcurrentTime","BECT_Convert_Type","Volume","Speed","Repeat_Time"],
				//F_0000_:Function_ID_;FVB:Function_Variable_Begin;FVE:Function_Variable_End;
				//==========
				//	[0*9+0,
				//	"F_0000_#FVB#0,1,2#FVE#00.40.55.900-00.40.56.050,00.40.56.540-00.40.56.690,00.40.57.360-00.40.57.560",
				//	"F_0000_#FVB#0,1,2#FVE#00.40.56.050-00.40.56.200,00.40.56.690-00.40.56.840,00.40.57.560-00.40.57.760",
				//	0,
				//	"0.84,0.84,0.84",
				//	"F_0000_#FVB#0,1,2#FVE#'0.3-1.2','0.3-1.2','0.4-1.6'",
				//	1],
				//==========
				//	[0*9+0,
				//	"F_0000_#FVB#0,1,2#FVE#00.40.55.900,00.40.56.540,00.40.57.360",
				//	"F_0000_#FVB#0,1,2#FVE#00.40.56.200,00.40.56.840,00.40.57.760",
				//	0,
				//	"0.84,0.84,0.84",
				//	"F_0000_#FVB#0,1,2#FVE#'0.3-1.2','0.3-1.2','0.4-1.6'",
				//	1],
				//==========
					[0*9+0,
					"F_0000_#FVB#0,1,2#FVE#00.40.55.900,00.40.56.540,00.40.57.360",
					"F_0000_#FVB#0,1,2#FVE#00.40.56.200,00.40.56.840,00.40.57.760",
					0,
					"0.84,0.84,0.84",
					"F_0000_#FVB#0,1,2#FVE#'0.3-1.2','0.3-1.2','0.4-1.6'",
					1],

					[0*9+0,
					"F_TA_#FVB#0,1,2#FVE#00.40.55.900,00.40.56.540,00.40.57.360",
					"F_TA_#FVB#0,1,2#FVE#00.40.56.200,00.40.56.840,00.40.57.760",
					0,
					"0.84,0.84,0.84",
					"F_TA_#FVB#0,1,2#FVE#'0.3-1.2','0.3-1.2','0.4-1.6'",
					1],
				//==========
				//==========DIVISION==========
			],
		],
	],
	//==============================DIVISION==============================
	[
		[
			[{Name:"真、善、忍◯",Type:3,Audio_List_ID:1,
				//	Cycle_Outer:[1],	Cycle_Inner:[[1,3]],
				//	Cycle_Outer:[1],	Cycle_Inner:[[1,"'1-3'"]],
				Cycle_Outer:[1],	Cycle_Inner:[["'1-3'","'1-3'"]],
				Random_Order_Inner:[1],	Random_Order_Inner_Inner:[[0,1]],
				New_MP3_ARR:[]}],//Multi_MP3_Tunnel;
			[
				//==========DIVISION==========
				//FIA:Function_INT_ALL;
				//FIB:Function_INT_Begin;
				//FIE:Function_INT_End;
				//FFA:Function_FLOAT_ALL;
				//FFB:Function_FLOAT_Begin;
				//FFE:Function_FLOAT_End;
				//==========DIVISION==========
				[
				//==========DIVISION==========
				//	[0*9+0,"00.40.55.900","00.40.56.200",0,1,1,1],		//0.300
				//	[0*9+0,"00.40.56.540","00.40.56.840",0,1,1.5,1],	//0.300
				//	[0*9+0,"00.40.57.360","00.40.57.760",0,1,2,1],		//0.400
				//==========DIVISION==========
				//	[0*9+0,"00.40.55.900","00.40.56.200",0,1,0.75,1],	["1*9+0,1*9+0,1*9+0","00.40.55.900,00.40.56.540,00.40.57.360","00.40.56.200,00.40.56.840,00.40.57.760",0,1,1,1],
				//==========DIVISION==========
					//	[0*9+0,"00.40.55.900","00.40.56.200",0,1,1,1],				
					//	[0*9+0,"00.40.56.540","00.40.56.840",0,1,30/30,1],			
					//	[0*9+0,"00.40.57.360","00.40.57.760",0,1,40/30,"'1-3'"],	
					[0*9+0,"00.40.55.900","00.40.56.200",0,1,"'FFB(30/30)-0.2FFE(30/30)+0.2'","'1-3'"],
					[0*9+0,"00.40.56.540","00.40.56.840",0,1,"'FFB(30/30)-0.2FFE(30/30)+0.2'","'1-3'"],
					[0*9+0,"00.40.57.360","00.40.57.760",0,1,"'FFB(40/30)-0.2FFE(40/30)+0.2'","'1-3'"],
				],
				//==========DIVISION==========
				[
					[0*9+0,"00.40.55.900","00.40.56.200",0,1,"'FFB(30/30)-0.2FFE(30/30)+0.2'","'1-3'"],
					[0*9+0,"00.40.56.540","00.40.56.840",0,1,"'FFB(30/30)-0.2FFE(30/30)+0.2'","'1-3'"],
					[0*9+0,"00.40.57.360","00.40.57.760",0,1,"'FFB(40/30)-0.2FFE(40/30)+0.2'","'1-3'"],
				],
				//==========DIVISION==========
			],
		],
	],
	//==============================DIVISION==============================
	[
		[
			[{Name:"真善忍喊：救命啊！",Type:1}],
			[
				[1,0,"00.40.55.870","00.40.58.500",0,1,1],
				[1,7,"00.23.15.120","00.23.16.400",0,1,1],
			],
		],
	],
	//==============================DIVISION==============================
	[
		[
			//"Guangzhou40k_3.mp3"	01.33.02.820-01.33.03.420	李洪志
			//"Guangzhou40k_1.mp3"	00.40.55.900-00.40.56.200	真
			//"Guangzhou40k_1.mp3"	00.40.56.540-00.40.56.840	善
			//"Guangzhou40k_1.mp3"	00.40.57.360-00.40.57.760	忍
			[{Name:"李洪志真、李洪志善、李洪志忍。",Type:2,Audio_List_ID:4,Cycle_Outer:[1],New_MP3_ARR:[""]}],//Multi_MP3_Tunnel;
			[
					[1*9+2,"01.33.02.820","01.33.03.420",0,1,0.75,1],

					[1*9+0,
					"F_TA_#FVB#0,1,2#FVE#00.40.55.900,00.40.56.540,00.40.57.360",
					"F_TA_#FVB#0,1,2#FVE#00.40.56.200,00.40.56.840,00.40.57.760",
					0,
					"0.84,0.84,0.84",
					"F_TA_#FVB#0,1,2#FVE#'0.3-1.2','0.3-1.2','0.4-1.6'",
					1],
			],
		],
	],
	//==============================DIVISION==============================
	[
		[
			//"Guangzhou40k_5.mp3"	00.36.14.000-00.36.14.300	包//钱包	00.36.13.780-00.36.14.300	包//钱包
			//"Guangzhou40k_8.mp3"	00.14.09.740-00.14.09.950	包//大气包	00.14.09.790-00.14.10.000	包//大气包
			//"Guangzhou40k_1.mp3"	00.19.18.220-00.19.18.480	剪//这简直	00.19.18.070-00.19.18.600	剪//这简直
			//"Guangzhou40k_7.mp3"	01.07.02.950-01.07.03.190	//			01.07.03.040-01.07.03.280	锤//垂
			[{Name:"李洪志包、李洪志剪、李洪志锤。",Type:2,Audio_List_ID:4,Cycle_Outer:[1],New_MP3_ARR:[""]}],//Multi_MP3_Tunnel;
			[
					[1*9+2,"01.33.02.820","01.33.03.420",0,1,0.75,1],

					["1*9+7,1*9+0,1*9+6",
					"F_TA_#FVB#0,1,2#FVE#00.14.09.740,00.19.18.220,01.07.02.950",
					"F_TA_#FVB#0,1,2#FVE#00.14.09.950,00.19.18.480,01.07.03.190",
					0,
					"F_TA_#FVB#0,1,2#FVE#'0.21-0.84','0.21-0.84','0.21-0.84'",
					"F_TA_#FVB#0,1,2#FVE#'0.21-0.84','0.26-1.04','0.26-1.04'",
					1],
			],
		],
	],
	//==============================DIVISION==============================
	[
		//Dalian40k_7.mp3
		[
			[{Name:"有一个灵体卧在那里。_00",Type:0,Audio_List_ID:4}],
			[
				[0*9+6,"00.67.22.240","00.67.24.160",0,1,1],
			],
		],
		//Jinan40k_2.mp3
		[
			[{Name:"也会...和真的隔墙看物、透视人体。",Type:0,Audio_List_ID:4}],
			[
				//[2*9+1,"00.23.10.200","00.23.13.700",0,1,1],
				[2*9+1,"00.23.11.750","00.23.13.200",0,1,1],
			],
		],
		[
			//洗澡、浴缸。
			[{Name:"洗澡啊。",Type:0,Audio_List_ID:4}],
			[
				[1*9+6,"00.13.55.100","00.13.55.800",0,1,1],
				//[1*9+6,"00.13.55.100","00.13.55.500",0,1,1],
			],
		],
		[
			[{Name:"啊...这个人在穿上衣服和不穿衣服都一样，你这玩意就能看。",Type:0,Audio_List_ID:4}],
			[
				//[2*9+1,"00.23.30.050","00.23.34.050",0,1,1],
				[2*9+1,"00.23.30.920","00.23.34.050",0,1,1],
			],
		],
		[
			[{Name:"所以他是很讨厌的。",Type:0,Audio_List_ID:4}],
			[
				[2*9+6,"00.38.51.350","00.38.52.450",0,1,1],
			],
		],
	],
	[
		//Dalian40k_7.mp3
		[
			[{Name:"有一个灵体卧在那里。_01",Type:0,Audio_List_ID:4}],
			[
				[0*9+6,"00.67.22.240","00.67.24.160",0,1,1],
			],
		],
		//Dalian40k_2.mp3
		[
			[{Name:"它能够隔墙看物、透视人体。",Type:0,Audio_List_ID:4}],
			[
				[0*9+1,"00.31.11.930","00.31.15.230",0,1,1],
				//[0*9+1,"00.31.12.430","00.31.15.230",0,1,1],
			],
		],
		[
			//洗澡、浴缸。
			[{Name:"洗澡啊。",Type:0,Audio_List_ID:4}],
			[
				[1*9+6,"00.13.55.100","00.13.55.800",0,1,1],
				//[1*9+6,"00.13.55.100","00.13.55.500",0,1,1],
			],
		],
		//[{Name:"一个个都是透视人体，啊走在街上，这穿衣服和不穿衣服一样。你在家里面，墙也隔不住，国家机密也保住不了。",Type:0,Audio_List_ID:4}],
		[
			[{Name:"这穿衣服和不穿衣服一样。",Type:0,Audio_List_ID:4}],
			[
				[0*9+1,"00.31.29.510","00.31.31.750",0,1,1],
			],
		],
		[
			[{Name:"所以他是很讨厌的。",Type:0,Audio_List_ID:4}],
			[
				[2*9+6,"00.38.51.350","00.38.52.450",0,1,1],
			],
		],
	],
	[
		//Dalian40k_7.mp3
		[
			[{Name:"有一个灵体卧在那里。_02",Type:0,Audio_List_ID:4}],
			[
				[0*9+6,"00.67.22.240","00.67.24.160",0,1,1],
			],
		],
		//Dalian40k_2.mp3
		[
			[{Name:"它能够隔墙看物、透视人体。",Type:0,Audio_List_ID:4}],
			[
				[0*9+1,"00.31.11.930","00.31.15.230",0,1,1],
				//[0*9+1,"00.31.12.430","00.31.15.230",0,1,1],
			],
		],
		//Guangzhou40k_8.mp3
		[
			[{Name:"「人在房间里，你在外面都看到了；」",Type:0,Audio_List_ID:4}],
			[
				[1*9+7,"00.23.10.080","00.23.10.550",0,1,1],
				[0*9+1,"00.36.48.560","00.36.48.900",0,1,1],//[0*9+1,"00.36.48.630","00.36.48.970",0,1,1],
				//还在这里
				//[0*9+1,"00.51.28.600","00.51.29.650",0,1,1],
				[0*9+1,"00.51.29.180","00.51.29.650",0,1,1],
				//我在
				//[1*9+3,"00.47.39.000","00.51.29.650",0,1,1],
				//你在
				[1*9+0,"00.66.14.530","00.66.14.710",0,1,0.5],//[1*9+0,"00.66.14.610","00.66.14.790",0,1,1],
				//[1*9+0,"00.66.16.420","00.66.16.630",0,1,1],
				[1*9+0,"00.49.56.300","00.49.56.500",0,1,1],//[1*9+0,"00.49.56.350","00.49.56.550",0,1,1],
				//看到钱
				//[1*9+1,"00.23.48.000","00.49.56.550",0,1,1],
				//到了很亮的外面的时候呢，
				//外面
				[1*9+1,"00.14.39.280","00.14.39.540",0,1,0.7],//[1*9+1,"00.14.39.330","00.14.39.590",0,1,1],
				//都看见了。
				//[1*9+1,"00.50.53.600","00.50.54.200",0,1,1],
				//都
				//[1*9+8,"00.50.53.600","00.50.53.700",0,1,1],
				//你为我、我为你，大家都这么好的时候。
				//都
				//[1*9+8,"00.56.45.920","00.56.46.050",0,1,1],//[1*9+8,"00.56.45.920","00.56.46.080",0,1,1],
				//不都好了嘛。
				//都
				[1*9+8,"00.56.52.440","00.56.52.610",0,1,1],
				//我看到了这些事情。
				//看到了
				[1*9+8,"00.51.07.460","00.51.07.850",0,1,0.8],//[1*9+8,"00.51.07.490","00.51.07.880",0,1,0.8],
			],
		],
		[
			//洗澡、浴缸。
			[{Name:"洗澡啊。",Type:0,Audio_List_ID:4}],
			[
				[1*9+6,"00.13.55.100","00.13.55.800",0,1,1],
				//[1*9+6,"00.13.55.100","00.13.55.500",0,1,1],
			],
		],
		//[{Name:"一个个都是透视人体，啊走在街上，这穿衣服和不穿衣服一样。你在家里面，墙也隔不住，国家机密也保住不了。",Type:0,Audio_List_ID:4}],
		[
			[{Name:"这穿衣服和不穿衣服一样。",Type:0,Audio_List_ID:4}],
			[
				[0*9+1,"00.31.29.510","00.31.31.750",0,1,1],
			],
		],
		[
			[{Name:"所以他是很讨厌的。",Type:0,Audio_List_ID:4}],
			[
				[2*9+6,"00.38.51.350","00.38.52.450",0,1,1],
			],
		],
	],
	//==============================DIVISION==============================
];
//==========DIVISION==========
ASP_CLS.VAL.Audio_Section_Data_STR_ARR=[];
function Audio_Section_Data_INI_FUN()
{
	//==========DIVISION==========
	var i,j,k,m,n;
	var TAB_STR="\tj";
	var TAB_STR="\t";
	var TAB_STR=" ".repeat(4);
	//==========DIVISION==========
	var Audio_Section_Data_ARR			=ASP_CLS.VAL.Audio_Section_Data_ARR;
	var Audio_Section_Data_STR_ARR		=ASP_CLS.VAL.Audio_Section_Data_STR_ARR;
	//==========DIVISION==========
	Audio_Section_Data_STR_ARR=createArray(Audio_Section_Data_ARR.length);
	for (i=0;i<Audio_Section_Data_ARR.length;i++)
	{
		Audio_Section_Data_STR_ARR[i]="";
		Audio_Section_Data_STR_ARR[i]+="[" + "\n";
		for (j=0;j<Audio_Section_Data_ARR[i].length;j++)
		{
			Audio_Section_Data_STR_ARR[i]+=TAB_STR + "[" + "\n";
			for (k=0;k<Audio_Section_Data_ARR[i][j].length;k++)
			{
				if ( k==0 )
				{
					Audio_Section_Data_STR_ARR[i]+=TAB_STR.repeat(2) + JSON.stringify(Audio_Section_Data_ARR[i][j][k]) + "," + "\n";
				}
				else if ( k>=1 )
				{
					Audio_Section_Data_STR_ARR[i]+=TAB_STR.repeat(2) + "[" + "\n";
					for (m=0;m<Audio_Section_Data_ARR[i][j][k].length;m++)
					{
						Audio_Section_Data_STR_ARR[i]+=TAB_STR.repeat(3) + JSON.stringify(Audio_Section_Data_ARR[i][j][k][m]) + "," + "\n";
					}
					Audio_Section_Data_STR_ARR[i]+=TAB_STR.repeat(2) + "]," + "\n";
				}
				else		{}
			}
			Audio_Section_Data_STR_ARR[i]+=TAB_STR + "]," + "\n";
		}
		Audio_Section_Data_STR_ARR[i]+="]," + "\n";
		//console.log(Audio_Section_Data_STR_ARR[i]);
	}
	ASP_CLS.VAL.Audio_Section_Data_STR_ARR=Audio_Section_Data_STR_ARR;
	//==========DIVISION==========
	//==========DIVISION==========
	//==========DIVISION==========
	//==========DIVISION==========
	//==========DIVISION==========
}
Audio_Section_Data_INI_FUN();
//==========DIVISION==========
ASP_CLS.VAL.Audio_Section_Data_Name_ARR=[];
//==========DIVISION==========
Audio_Section_Data_ARR_INI();
//==========DIVISION==========
//====================DIVISION====================
//==========DIVISION==========
/*
Audio_Section_Player.html?asda=
	[
		[
			[{Name:"真善忍喊：救命啊！",Type:1}],
			[
				[1,0,"00.40.55.870","00.40.58.500",0,1,1],
				[1,7,"00.23.15.120","00.23.16.400",0,1,1],
			],
		],
	],
&w=...
*/
//==========DIVISION==========
//====================DIVISION====================
